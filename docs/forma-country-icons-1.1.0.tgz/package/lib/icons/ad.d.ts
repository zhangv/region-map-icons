import type { IconDefinition } from '../index.js';
declare const icon: Readonly<IconDefinition>;
export default icon;
